Name: Pulindu Fonseka
CIS code: cfcf66



The following instructions will show you how to run the program and test the classifier. 

RUN PROGRAM:
Run:
    python main.py image_processing_files/xray_images/
Test:
    python classify.py --data=Results --model=classifier.model

Note:   Ensure that the terminal is in the correct file path.